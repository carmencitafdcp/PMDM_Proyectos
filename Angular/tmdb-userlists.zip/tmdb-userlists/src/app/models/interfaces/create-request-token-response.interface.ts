export interface CreateRequestTokenResponse {
  success: boolean
  expires_at: string
  request_token: string
}