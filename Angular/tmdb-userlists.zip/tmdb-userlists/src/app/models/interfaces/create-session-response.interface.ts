export interface CreateSessionResponse {
      success: boolean;
  session_id: string;
}