import { Genre } from "./genre.interface";

export interface GenresMovieListResponse {
  genres: Genre[]
}