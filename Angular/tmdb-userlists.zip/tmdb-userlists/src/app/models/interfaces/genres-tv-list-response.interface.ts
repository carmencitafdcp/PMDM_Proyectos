import { Genre } from "./genre.interface";

export interface GenresTvListResponse {
  genres: Genre[]
}